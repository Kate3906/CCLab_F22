function selectLove() {
    localStorage.setItem("choice", "love");
    window.open("page-love.html", "_self");
}

function selectStudy() {
    localStorage.setItem("choice", "study");
    window.open("page-study.html", "_self");
}
